/* BSaudit shared helpers + example data (loaded by index.html and detail.html) */
const esc=s=>String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const colFor=n=>n>=80?'#1fb86b':n>=60?'#3d8bff':n>=40?'#f5a524':'#ff5252';
function lbl(n){return n>=80?'Strong. Keep it up and fine-tune.':n>=60?'Good foundations, with clear room to improve':n>=40?'Some important gaps worth fixing soon':'Needs attention: the next steps will show where to start'}
const bandName=n=>n>=80?'Strong':n>=60?'Good':n>=40?'Some gaps':'Needs attention';

/* What each card checks (taken from the "What we look at" part of the guide).
   `from` = which breakdown rows (br[]) feed that check. */
const CHECKS={
 Website:[
  {t:'Speed and ease of use',from:[0,1],
   d:'How quickly your website loads and how easy it is to use, on phones and on computers.',
   why:'Slow or hard-to-use pages make visitors leave before they find what they came for.',
   look:['How quickly the first content appears','How quickly the main content has loaded','Whether the page jumps around while loading','Whether it works well with keyboards, screen readers and clear colours']},
  {t:'Clarity for search engines',from:[3],
   d:'How clearly your website explains your business to search engines like Google.',
   why:'If search engines can’t tell what you do, the right customers can’t find you.',
   look:['Page titles and page descriptions','Headings and readable text','Whether your pages can be found and listed','A layout that works on mobile']},
  {t:'The basics',from:[2],
   d:'The essentials every business website should have in place.',
   why:'Security, tidy code and working links are what customers and Google use to decide whether to trust a site.',
   look:['Secure connection (HTTPS)','No browser errors or outdated code','Safe, modern ways of loading images and scripts'],
   later:['Working links to your social channels']}
 ],
 Social:[
  {t:'Profile completeness',from:[0],
   d:'Is your profile complete: photo, description, contact details and a website link?',
   why:'A complete profile builds trust and makes it easy for people to reach you.',
   look:['Profile photo or logo','Description or bio','Contact details','Website link']},
  {t:'Links between channels',from:[1],
   d:'Do your channels link back to your website, and to each other?',
   why:'Linking everything together helps customers and search engines confirm these all belong to one business.',
   look:['A link to your website','Links to your other channels','The same name and wording everywhere']},
  {t:'Activity',from:[2],
   d:'How active you are: how often you post and how recently.',
   why:'Regular, recent posts show customers that you are open and paying attention.',
   look:['How often you post','How recently you last posted']},
  {t:'Public signals',from:[3],
   d:'Public signals such as followers and engagement, where the platform shares them.',
   why:'Followers and engagement show how people respond to you. We only use what the platform makes public.',
   look:['Number of followers','Engagement, such as likes and comments']}
 ]
};

/* Example figures (shown until a real audit is run). Every score is the average of its breakdown. */
const SAMPLE=[
{n:'Website',s:78,c:'#1fb86b',t:'Fast, clear, a few fixes',
 f:['Loads quickly on phones and computers','Page titles and descriptions are in place','Secure connection is working'],
 x:[{t:'Add working links to your social channels',p:'High',why:'Visitors and search engines use these links to confirm your channels belong to you.',how:'Add links to Instagram, Facebook and LinkedIn in your website header or footer, then click each one to make sure it opens the right profile.'},
    {t:'Tighten a few page descriptions',p:'Medium',why:'The short description under your page title is often what people read in search results.',how:'Give each key page its own one-sentence description that says what you offer and where.'}],
 br:[['Performance',82],['Accessibility',76],['Best practices',80],['Search visibility (SEO)',74]]},
{n:'Instagram',s:64,c:'#3d8bff',t:'Good profile, posts are irregular',
 f:['Profile photo and bio are complete','Website link is present'],
 x:[{t:'Post on a steady schedule',p:'High',why:'Regular posts show visitors you are active and keep your account in front of your followers.',how:'Choose a rhythm you can keep, such as a few posts a week, and prepare posts in batches.'},
    {t:'Match your bio wording to your other channels',p:'Medium',why:'The same name and wording make your business easy to recognise everywhere.',how:'Copy your business name and one-line description from your website into your bio.'}],
 br:[['Profile completeness',85],['Links between channels',70],['Activity',40],['Public signals',60]]},
{n:'Facebook',s:71,c:'#3d8bff',t:'Complete page, link to site missing',
 f:['Page details and contact info are complete','Recent activity is visible'],
 x:[{t:'Add your website link to the page',p:'High',why:'Without it, people who find you on Facebook have no easy way to reach your website.',how:'Add your website address in the page’s About / contact details.'},
    {t:'Link to your Instagram profile',p:'Medium',why:'Cross-links let followers find you on every channel.',how:'Add your Instagram handle to the page details.'}],
 br:[['Profile completeness',90],['Links between channels',50],['Activity',75],['Public signals',70]]},
{n:'LinkedIn',s:55,c:'#f5a524',t:'Sparse profile, little recent activity',
 f:['Company page exists'],
 x:[{t:'Complete the description and logo',p:'High',why:'An empty company page looks inactive and gives people little reason to trust it.',how:'Add your logo, a short description of what you do and your contact details.'},
    {t:'Post a company update this month',p:'Medium',why:'A recent post shows the page is looked after.',how:'Share one real update, such as news, a project or a new offer.'},
    {t:'Link back to your website',p:'Medium',why:'It connects your company page with the rest of your online presence.',how:'Add your website address to the page details.'}],
 br:[['Profile completeness',50],['Links between channels',50],['Activity',35],['Public signals',85]]}
];

/* Hand the audit state from index.html to detail.html (sessionStorage, with window.name as a fallback for browsers that isolate local files) */
function bsSave(o){const j=JSON.stringify(o);try{sessionStorage.setItem('bsaudit.v1',j)}catch(_){}try{window.name='bsaudit:'+j}catch(_){}}
function bsLoad(){try{const j=sessionStorage.getItem('bsaudit.v1');if(j)return JSON.parse(j)}catch(_){}try{if(String(window.name).indexOf('bsaudit:')===0)return JSON.parse(window.name.slice(8))}catch(_){}return null}
