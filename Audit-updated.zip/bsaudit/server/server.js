/* BSaudit Facebook proxy. Keeps the App Secret and access token on the server.
   Run:  cp .env.example .env  (fill it in), then  node --env-file=.env server.js   (Node 20+) */
const http = require('http');
const crypto = require('crypto');

const { FB_APP_SECRET, FB_ACCESS_TOKEN, FB_API_VERSION = 'v27.0', ALLOWED_ORIGIN = '*', PORT = 8787 } = process.env;
if (!FB_APP_SECRET || !FB_ACCESS_TOKEN) { console.error('Set FB_APP_SECRET and FB_ACCESS_TOKEN in .env'); process.exit(1); }

/* fixed field list: the browser cannot ask for anything else */
const FIELDS = 'id,name,about,description,website,phone,emails,single_line_address,category,link,fan_count,followers_count,picture{url,is_silhouette},posts.limit(5){created_time}';
const proof = crypto.createHmac('sha256', FB_APP_SECRET).update(FB_ACCESS_TOKEN).digest('hex');

http.createServer(async (req, res) => {
  const send = (code, obj) => {
    res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': ALLOWED_ORIGIN, 'Vary': 'Origin' });
    res.end(JSON.stringify(obj));
  };
  if (req.method === 'OPTIONS') return send(204, {});
  const u = new URL(req.url, 'http://x');
  if (u.pathname !== '/fb') return send(404, { error: { message: 'Not found' } });
  const page = u.searchParams.get('page') || '';
  if (!/^[A-Za-z0-9.\-_]{1,100}$/.test(page)) return send(400, { error: { message: 'Invalid page', code: 100 } });
  try {
    const q = new URLSearchParams({ fields: FIELDS, access_token: FB_ACCESS_TOKEN, appsecret_proof: proof });
    const r = await fetch(`https://graph.facebook.com/${FB_API_VERSION}/${encodeURIComponent(page)}?${q}`);
    const j = await r.json().catch(() => ({}));
    if (j.error) { delete j.error.fbtrace_id; return send(r.status || 400, { error: { message: j.error.message, code: j.error.code } }); }
    send(200, j);
  } catch (e) { send(502, { error: { message: 'Upstream error' } }); }
}).listen(PORT, () => console.log('BSaudit Facebook proxy on http://localhost:' + PORT + '/fb'));
